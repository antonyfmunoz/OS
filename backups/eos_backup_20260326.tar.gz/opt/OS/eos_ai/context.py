from dataclasses import dataclass
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")


@dataclass
class EOSContext:
    org_id: str
    user_id: str
    portfolio_id: str | None = None
    active_venture_id: str | None = None
    active_agent_id: str | None = None


def load_context_from_env() -> EOSContext:
    return EOSContext(
        org_id=os.environ["EOS_ORG_ID"],
        user_id=os.environ["EOS_USER_ID"],
        portfolio_id=os.environ.get("EOS_PORTFOLIO_ID"),
    )
