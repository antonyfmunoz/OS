"""
PrincipleEngine — injects quality standards into every AI decision.

The root rule is the permanent foundation. All other principles derive from it.
Principles are injected universally so skills stay focused on execution logic only.
"""

from __future__ import annotations

from eos_ai.context import EOSContext


# ─── Root Rule ────────────────────────────────────────────────────────────────

ROOT_RULE = (
    "The system must always seek the highest justified standard of knowledge, "
    "execution, and quality for the task at hand, then adapt that standard to "
    "the user's current stage without unnecessary complexity or waste."
)


# ─── Principle Domains ────────────────────────────────────────────────────────

REALITY_PRINCIPLES = {
    "universal": [
        ROOT_RULE,
        "Proof always precedes claims. Assert only what has been verified.",
        "Every output must serve a specific, measurable business outcome.",
        "Complexity is a liability — use the simplest solution that fully solves the problem.",
        "Read before writing. Understand before modifying.",
    ],
    "sales": [
        "Qualify ruthlessly — time spent on disqualified leads is wasted.",
        "Mirror exact ICP language; never translate their words into your own framing.",
        "One clear next action per conversation — no ambiguity about what happens next.",
        "Pain before pitch — the ICP must articulate their problem before the offer is introduced.",
        "Silence is a signal — stalled momentum requires a diagnosis, not pressure.",
    ],
    "content": [
        "The first line is the only line that matters for stopping the scroll.",
        "Every piece of content serves one role: attract the ICP or repel everyone else.",
        "Content IS the advertising — no fourth-wall breaks, no pitching.",
        "Hooks must create curiosity, friction, or pattern interruption — anything else is noise.",
        "Depth beats volume — one resonant post outperforms ten generic ones.",
    ],
    "research": [
        "Raw signals are worthless without interpretation — every signal needs a so-what.",
        "ICP intelligence compounds — store every insight so patterns emerge over time.",
        "Exact language from real people always beats AI-generated paraphrases.",
        "One sharp specific insight beats five vague observations.",
        "Pattern frequency is signal strength — track how often each insight recurs.",
    ],
    "ops": [
        "Systems replace willpower — automate recurring decisions, not one-offs.",
        "Every bottleneck has a root cause — fix the cause, not the symptom.",
        "A process that isn't measured isn't a process — add a metric or delete it.",
        "Agendas exist to produce decisions, not to fill time.",
        "Blockers must be escalated immediately — waiting compounds cost.",
    ],
    "analyze": [
        "Separate facts from interpretations in every analysis.",
        "The binding constraint is the only thing that matters — find it first.",
        "Data without context misleads — always state assumptions.",
        "Patterns matter more than individual data points.",
        "Conclusions must be falsifiable — state what evidence would change them.",
    ],
    "strategy": [
        "North star over noise — every strategic decision traces back to the current goal.",
        "Pre-revenue stage: only actions that produce first revenue qualify as priorities.",
        "Optionality is expensive — fewer bets pursued harder beats many bets half-done.",
        "The binding constraint owns all available resources until it's resolved.",
        "Strategy that cannot be executed is not strategy — it is wishful thinking.",
    ],
}


# ─── PrincipleEngine ──────────────────────────────────────────────────────────

class PrincipleEngine:
    """
    Injects the root rule and domain-relevant principles into every AI task.

    Usage:
        pe = PrincipleEngine(ctx)
        principles = pe.get_relevant_principles('sales', 'lyfe_institute')
        # Returns list with ROOT_RULE first, then domain-specific principles.
    """

    def __init__(self, ctx: EOSContext) -> None:
        self.ctx = ctx

    # ─── get_relevant_principles ─────────────────────────────────────────────

    def get_relevant_principles(
        self,
        task_type: str,
        venture_id: str | None = None,
    ) -> list[str]:
        """
        Return principles relevant to the task type.
        ROOT_RULE is always first — it is the permanent root.

        Args:
            task_type:  Task domain — 'sales', 'content', 'research', 'ops',
                        'analyze', 'strategy', or any key in REALITY_PRINCIPLES.
            venture_id: Optional — reserved for venture-specific overrides.

        Returns:
            List of principle strings, ROOT_RULE always at index 0.
        """
        principles: list[str] = []

        # Root rule — always first, never removed
        principles.append(ROOT_RULE)

        # Universal principles — always injected after root rule
        for p in REALITY_PRINCIPLES["universal"]:
            if p not in principles:
                principles.append(p)

        # Domain-specific principles
        domain = task_type.lower() if task_type else ""
        if domain in REALITY_PRINCIPLES:
            for p in REALITY_PRINCIPLES[domain]:
                if p not in principles:
                    principles.append(p)
        elif domain:
            # Fallback: check if domain is a substring of any key
            for key, domain_principles in REALITY_PRINCIPLES.items():
                if key in domain or domain in key:
                    for p in domain_principles:
                        if p not in principles:
                            principles.append(p)
                    break

        return principles

    # ─── format_for_prompt ───────────────────────────────────────────────────

    def format_for_prompt(
        self,
        task_type: str,
        venture_id: str | None = None,
    ) -> str:
        """
        Return principles formatted as a prompt block for injection into AI calls.
        """
        principles = self.get_relevant_principles(task_type, venture_id)
        lines = ["OPERATING PRINCIPLES (apply to every output):"]
        for i, p in enumerate(principles):
            prefix = "ROOT:" if i == 0 else f"  {i}."
            lines.append(f"{prefix} {p}")
        return "\n".join(lines)

    # ─── get_root_rule ───────────────────────────────────────────────────────

    @staticmethod
    def get_root_rule() -> str:
        """Return the permanent root rule."""
        return ROOT_RULE

    # ─── list_domains ────────────────────────────────────────────────────────

    @staticmethod
    def list_domains() -> list[str]:
        """Return all available principle domains."""
        return list(REALITY_PRINCIPLES.keys())
