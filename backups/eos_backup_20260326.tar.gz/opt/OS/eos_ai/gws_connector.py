"""
GWSConnector — Google Workspace integration via gws CLI.

Provides calendar, tasks, drive, and gmail access for EOS agents.
All methods are safe — they log warnings on error and never crash.

Usage:
    from eos_ai.gws_connector import GWSConnector
    gws = GWSConnector()
    events = gws.get_today_events()
    tasks  = gws.get_tasks()
"""

import json
import subprocess
from datetime import datetime, timezone, timedelta
from pathlib import Path as _Path
from dotenv import load_dotenv as _load_dotenv
_ROOT = _Path(__file__).parent.parent
_load_dotenv(_ROOT / '13_Scripts' / '.env')
_load_dotenv(_ROOT / 'eos_ai' / '.env', override=True)


class GWSConnector:

    # ── Core runner ───────────────────────────────────────────────────────────

    def _run(self, *args, params: dict | None = None) -> dict | None:
        """
        Run a gws CLI command and return parsed JSON, or None on error.
        Strips the "Using keyring backend: keyring" line before parsing.
        """
        cmd = ["npx", "@googleworkspace/cli"] + list(args)
        if params:
            cmd += ["--params", json.dumps(params)]

        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30
            )
            output = result.stdout
            lines = output.split("\n")
            clean = "\n".join(
                l for l in lines if not l.startswith("Using keyring")
            )
            clean = clean.strip()
            if not clean:
                return None
            return json.loads(clean)
        except Exception as e:
            print(f"[GWS] Command failed: {e}")
            return None

    # ── Calendar ──────────────────────────────────────────────────────────────

    def get_today_events(self) -> list[dict]:
        now   = datetime.now(timezone.utc)
        start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        end   = now.replace(hour=23, minute=59, second=59, microsecond=0).isoformat()
        data  = self._run(
            "calendar", "events", "list",
            params={
                "calendarId":   "primary",
                "timeMin":      start,
                "timeMax":      end,
                "maxResults":   20,
                "singleEvents": True,
                "orderBy":      "startTime",
            },
        )
        if not data:
            return []
        return [
            {
                "title":       e.get("summary", "Untitled"),
                "start":       e.get("start", {}).get("dateTime") or e.get("start", {}).get("date"),
                "end":         e.get("end",   {}).get("dateTime") or e.get("end",   {}).get("date"),
                "location":    e.get("location", ""),
                "description": e.get("description", "")[:200],
                "meet_link":   e.get("hangoutLink", ""),
            }
            for e in data.get("items", [])
        ]

    def get_upcoming_events(self, days: int = 7) -> list[dict]:
        now  = datetime.now(timezone.utc)
        end  = now + timedelta(days=days)
        data = self._run(
            "calendar", "events", "list",
            params={
                "calendarId":   "primary",
                "timeMin":      now.isoformat(),
                "timeMax":      end.isoformat(),
                "maxResults":   20,
                "singleEvents": True,
                "orderBy":      "startTime",
            },
        )
        if not data:
            return []
        return [
            {
                "title":     e.get("summary", "Untitled"),
                "start":     e.get("start", {}).get("dateTime") or e.get("start", {}).get("date"),
                "end":       e.get("end",   {}).get("dateTime") or e.get("end",   {}).get("date"),
                "location":  e.get("location", ""),
                "meet_link": e.get("hangoutLink", ""),
            }
            for e in data.get("items", [])
        ]

    def create_calendar_event(
        self,
        title: str,
        start_iso: str | None = None,
        duration_minutes: int = 60,
        attendee_email: str | None = None,
        description: str = "",
    ) -> dict | None:
        """
        Create a Google Calendar event with a Google Meet link.
        start_iso: ISO datetime string (UTC). Defaults to now + 5 minutes.
        Returns dict with title, start, meet_link, event_id or None on failure.
        """
        import uuid as _uuid
        now = datetime.now(timezone.utc)
        if start_iso:
            try:
                from dateutil.parser import parse as _parse
                start_dt = _parse(start_iso)
            except Exception:
                start_dt = now + timedelta(minutes=5)
        else:
            start_dt = now + timedelta(minutes=5)

        end_dt = start_dt + timedelta(minutes=duration_minutes)

        params: dict = {
            "calendarId":           "primary",
            "conferenceDataVersion": 1,
            "body": {
                "summary":     title,
                "description": description,
                "start":  {"dateTime": start_dt.isoformat(), "timeZone": "UTC"},
                "end":    {"dateTime": end_dt.isoformat(),   "timeZone": "UTC"},
                "reminders": {
                    "useDefault": False,
                    "overrides": [{"method": "popup", "minutes": 10}],
                },
                "conferenceData": {
                    "createRequest": {
                        "requestId": str(_uuid.uuid4()),
                        "conferenceSolutionKey": {"type": "hangoutsMeet"},
                    }
                },
            },
        }
        if attendee_email:
            params["body"]["attendees"] = [{"email": attendee_email}]

        data = self._run("calendar", "events", "insert", params=params)
        if not data:
            return None
        return {
            "event_id":  data.get("id", ""),
            "title":     data.get("summary", title),
            "start":     data.get("start", {}).get("dateTime", ""),
            "meet_link": data.get("hangoutLink", ""),
        }

    # ── Tasks ─────────────────────────────────────────────────────────────────

    TASKLIST_ID = "MTI0OTc0NTUyNTc5NjUzNjQwOTI6MDow"

    def get_tasks(self) -> list[dict]:
        data = self._run(
            "tasks", "tasks", "list",
            params={
                "tasklist":      self.TASKLIST_ID,
                "showCompleted": False,
                "maxResults":    50,
            },
        )
        if not data:
            return []
        return [
            {
                "id":     t.get("id"),
                "title":  t.get("title", ""),
                "notes":  t.get("notes", ""),
                "due":    t.get("due", ""),
                "status": t.get("status", ""),
            }
            for t in data.get("items", [])
            if t.get("status") != "completed"
        ]

    def create_task(
        self,
        title: str,
        notes: str = "",
        due: str | None = None,
    ) -> dict | None:
        params: dict = {
            "tasklist": self.TASKLIST_ID,
            "title":    title,
        }
        if notes:
            params["notes"] = notes
        if due:
            params["due"] = due
        return self._run("tasks", "tasks", "insert", params=params)

    def complete_task(self, task_id: str) -> bool:
        result = self._run(
            "tasks", "tasks", "patch",
            params={
                "tasklist": self.TASKLIST_ID,
                "task":     task_id,
                "status":   "completed",
            },
        )
        return result is not None

    # ── Drive ─────────────────────────────────────────────────────────────────

    def search_drive(self, query: str, max_results: int = 10) -> list[dict]:
        data = self._run(
            "drive", "files", "list",
            params={
                "q":        query,
                "pageSize": max_results,
                "fields":   "files(id,name,mimeType,modifiedTime)",
            },
        )
        if not data:
            return []
        return data.get("files", [])

    def read_document(self, file_id: str) -> str:
        """Export a Google Doc as plain text (first 5000 chars)."""
        try:
            result = subprocess.run(
                [
                    "npx", "@googleworkspace/cli", "drive", "files", "export",
                    "--params",
                    json.dumps({"fileId": file_id, "mimeType": "text/plain"}),
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.stdout[:5000]
        except Exception:
            return ""

    # ── Gmail ─────────────────────────────────────────────────────────────────

    def get_recent_emails(
        self,
        max_results: int = 10,
        query: str = "",
    ) -> list[dict]:
        params: dict = {"userId": "me", "maxResults": max_results}
        if query:
            params["q"] = query
        data = self._run("gmail", "users", "messages", "list", params=params)
        if not data:
            return []

        messages = []
        for msg in data.get("messages", [])[:5]:
            detail = self._run(
                "gmail", "users", "messages", "get",
                params={
                    "userId":          "me",
                    "id":              msg["id"],
                    "format":          "metadata",
                    "metadataHeaders": ["Subject", "From", "Date"],
                },
            )
            if detail:
                headers = {
                    h["name"]: h["value"]
                    for h in detail.get("payload", {}).get("headers", [])
                }
                messages.append(
                    {
                        "id":      msg["id"],
                        "subject": headers.get("Subject", ""),
                        "from":    headers.get("From", ""),
                        "date":    headers.get("Date", ""),
                        "snippet": detail.get("snippet", "")[:200],
                    }
                )
        return messages

    def search_emails_from(
        self,
        sender: str,
        max_results: int = 5,
    ) -> list[dict]:
        return self.get_recent_emails(
            max_results=max_results,
            query=f"from:{sender}",
        )
